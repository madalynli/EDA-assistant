Read Me File:

This read me file is a temporary placeholder.<br> 
I plan to add more to this file as I continue to document and develop this package.